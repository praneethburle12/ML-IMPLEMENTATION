from flask import Flask, jsonify, send_from_directory, request
from flask_cors import CORS
import cv2
import mediapipe as mp
import numpy as np
import threading
import time
import json
import os
from collections import deque
from dataclasses import dataclass
from typing import List, Dict, Optional

app = Flask(__name__)
CORS(app)

# MediaPipe setup with optimized settings
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(
    max_num_hands=1,
    min_detection_confidence=0.75,
    min_tracking_confidence=0.75,
    model_complexity=1
)
mp_draw = mp.solutions.drawing_utils

@dataclass
class GestureData:
    name: str
    emoji: str
    finger_count: int
    confidence: float
    timestamp: float

class GestureRecognizer:
    def __init__(self, buffer_size=5):
        self.buffer = deque(maxlen=buffer_size)
        self.training_data = {}
        self.load_training_data()
    
    def load_training_data(self):
        """Load previously saved training data"""
        if os.path.exists('gesture_model.json'):
            try:
                with open('gesture_model.json', 'r') as f:
                    self.training_data = json.load(f)
                print(f"✓ Loaded training data with {len(self.training_data)} gestures")
            except Exception as e:
                print(f"Error loading training data: {e}")
    
    def save_training_data(self, data):
        """Save training data to file"""
        try:
            with open('gesture_model.json', 'w') as f:
                json.dump(data, f, indent=2)
            return True
        except Exception as e:
            print(f"Error saving training data: {e}")
            return False
    
    def count_fingers(self, landmarks) -> Dict:
        """Count extended fingers with improved accuracy"""
        fingers = {
            'thumb': False,
            'index': False,
            'middle': False,
            'ring': False,
            'pinky': False
        }
        
        # Thumb detection (check horizontal distance)
        thumb_tip = landmarks[4]
        thumb_base = landmarks[2]
        fingers['thumb'] = thumb_tip.x < thumb_base.x - 0.04
        
        # Other fingers (check vertical distance with adjusted threshold)
        finger_tips = [8, 12, 16, 20]
        finger_mids = [6, 10, 14, 18]
        finger_names = ['index', 'middle', 'ring', 'pinky']
        
        for tip, mid, name in zip(finger_tips, finger_mids, finger_names):
            fingers[name] = landmarks[tip].y < landmarks[mid].y - 0.015
        
        count = sum(fingers.values())
        return {'fingers': fingers, 'count': count}
    
    def detect_gesture(self, finger_data, landmarks) -> GestureData:
        """Detect gesture with pattern matching"""
        fingers = finger_data['fingers']
        count = finger_data['count']
        
        # Calculate distances for special gestures
        thumb_tip = np.array([landmarks[4].x, landmarks[4].y])
        index_tip = np.array([landmarks[8].x, landmarks[8].y])
        distance_thumb_index = np.linalg.norm(thumb_tip - index_tip)
        
        # Thumbs up
        if fingers['thumb'] and not any([fingers['index'], fingers['middle'], 
                                         fingers['ring'], fingers['pinky']]):
            return GestureData('Thumbs Up', '👍', count, 0.95, time.time())
        
        # Peace sign
        if (not fingers['thumb'] and fingers['index'] and fingers['middle'] and 
            not fingers['ring'] and not fingers['pinky']):
            return GestureData('Peace', '✌️', count, 0.95, time.time())
        
        # OK gesture
        if distance_thumb_index < 0.035 and fingers['middle'] and fingers['ring'] and fingers['pinky']:
            return GestureData('OK', '👌', count, 0.9, time.time())
        
        # Rock sign
        if (not fingers['thumb'] and fingers['index'] and not fingers['middle'] and 
            not fingers['ring'] and fingers['pinky']):
            return GestureData('Rock', '🤘', count, 0.95, time.time())
        
        # Pointing
        if (not fingers['thumb'] and fingers['index'] and not fingers['middle'] and 
            not fingers['ring'] and not fingers['pinky']):
            return GestureData('Pointing', '☝️', count, 0.95, time.time())
        
        # Number gestures
        emoji_map = {0: '✊', 1: '☝️', 2: '✌️', 3: '🤟', 4: '🖖', 5: '✋'}
        name = 'Fist' if count == 0 else f'{count} Finger{"s" if count > 1 else ""}'
        return GestureData(name, emoji_map.get(count, '👋'), count, 0.8, time.time())
    
    def add_to_buffer(self, gesture: GestureData):
        """Add gesture to smoothing buffer"""
        self.buffer.append(gesture)
    
    def get_smoothed_gesture(self) -> Optional[GestureData]:
        """Get most frequent gesture from buffer"""
        if not self.buffer:
            return None
        
        # Count occurrences
        gesture_counts = {}
        for g in self.buffer:
            key = g.name
            if key not in gesture_counts:
                gesture_counts[key] = []
            gesture_counts[key].append(g)
        
        # Get most frequent
        max_key = max(gesture_counts, key=lambda k: len(gesture_counts[k]))
        gestures = gesture_counts[max_key]
        
        # Return most recent of most frequent
        return gestures[-1]

# Global state
gesture_recognizer = GestureRecognizer(buffer_size=3)
current_gesture_data = None
camera_active = False
camera_lock = threading.Lock()
fps_counter = deque(maxlen=30)

def process_camera():
    """Optimized camera processing loop"""
    global current_gesture_data, camera_active
    
    cap = cv2.VideoCapture(0)
    
    # Optimize camera settings for performance
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
    cap.set(cv2.CAP_PROP_FPS, 30)
    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)  # Minimize latency
    
    print("📹 Camera initialized")
    camera_active = True
    
    frame_count = 0
    start_time = time.time()
    
    while camera_active:
        ret, frame = cap.read()
        if not ret:
            time.sleep(0.01)
            continue
        
        # Flip and convert
        frame = cv2.flip(frame, 1)
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        
        # Process with MediaPipe
        results = hands.process(rgb_frame)
        
        # Calculate FPS
        frame_count += 1
        if frame_count % 10 == 0:
            elapsed = time.time() - start_time
            fps = frame_count / elapsed if elapsed > 0 else 0
            fps_counter.append(fps)
        
        # Process results
        with camera_lock:
            if results.multi_hand_landmarks:
                landmarks = results.multi_hand_landmarks[0].landmark
                finger_data = gesture_recognizer.count_fingers(landmarks)
                gesture = gesture_recognizer.detect_gesture(finger_data, landmarks)
                gesture_recognizer.add_to_buffer(gesture)
                current_gesture_data = gesture_recognizer.get_smoothed_gesture()
            else:
                current_gesture_data = None
                gesture_recognizer.buffer.clear()
        
        # Small sleep to prevent CPU overload
        time.sleep(0.01)
    
    cap.release()
    print("📹 Camera stopped")

@app.route('/')
def index():
    return send_from_directory('.', 'gesture_nexus.html')

@app.route('/api/gesture')
def get_gesture():
    """Get current detected gesture"""
    with camera_lock:
        if current_gesture_data:
            avg_fps = sum(fps_counter) / len(fps_counter) if fps_counter else 0
            return jsonify({
                'gesture': current_gesture_data.name,
                'emoji': current_gesture_data.emoji,
                'fingerCount': current_gesture_data.finger_count,
                'confidence': current_gesture_data.confidence,
                'fps': round(avg_fps, 1),
                'timestamp': current_gesture_data.timestamp
            })
        else:
            return jsonify({
                'gesture': 'No Hand',
                'emoji': '👋',
                'fingerCount': 0,
                'confidence': 0,
                'fps': 0,
                'timestamp': time.time()
            })

@app.route('/api/camera/start', methods=['POST'])
def start_camera():
    """Start camera processing"""
    global camera_active
    
    if not camera_active:
        camera_thread = threading.Thread(target=process_camera, daemon=True)
        camera_thread.start()
        return jsonify({'status': 'started', 'message': 'Camera is now active'})
    else:
        return jsonify({'status': 'already_running', 'message': 'Camera is already active'})

@app.route('/api/camera/stop', methods=['POST'])
def stop_camera():
    """Stop camera processing"""
    global camera_active
    
    camera_active = False
    return jsonify({'status': 'stopped', 'message': 'Camera stopped'})

@app.route('/api/training/save', methods=['POST'])
def save_training():
    """Save training data"""
    try:
        data = request.json
        if gesture_recognizer.save_training_data(data):
            return jsonify({'status': 'success', 'message': 'Training data saved'})
        else:
            return jsonify({'status': 'error', 'message': 'Failed to save'}), 500
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/training/load', methods=['GET'])
def load_training():
    """Load training data"""
    gesture_recognizer.load_training_data()
    return jsonify({
        'status': 'success',
        'data': gesture_recognizer.training_data,
        'gestures': len(gesture_recognizer.training_data)
    })

@app.route('/api/stats')
def get_stats():
    """Get system statistics"""
    avg_fps = sum(fps_counter) / len(fps_counter) if fps_counter else 0
    return jsonify({
        'fps': round(avg_fps, 1),
        'camera_active': camera_active,
        'buffer_size': len(gesture_recognizer.buffer),
        'trained_gestures': len(gesture_recognizer.training_data)
    })

def print_banner():
    """Print startup banner"""
    print("\n" + "="*60)
    print("🤖 NEURAL NEXUS - Gesture Control System")
    print("="*60)
    print("\n📡 Server Information:")
    print(f"   ├─ URL: http://localhost:5000")
    print(f"   ├─ API: http://localhost:5000/api/gesture")
    print(f"   └─ Status: http://localhost:5000/api/stats")
    print("\n🎯 Features:")
    print("   ├─ Real-time gesture recognition")
    print("   ├─ Custom gesture training")
    print("   ├─ Gesture-controlled snake game")
    print("   └─ Optimized for low latency")
    print("\n⚡ Performance:")
    print("   ├─ Buffer smoothing: 3 frames")
    print("   ├─ Target FPS: 30+")
    print("   └─ Latency: <100ms")
    print("\n🎮 Controls:")
    print("   Press Ctrl+C to stop the server")
    print("="*60 + "\n")

if __name__ == '__main__':
    print_banner()
    
    # Auto-start camera
    camera_thread = threading.Thread(target=process_camera, daemon=True)
    camera_thread.start()
    
    # Run Flask server
    app.run(
        debug=False,  # Disable debug for better performance
        host='0.0.0.0',
        port=5000,
        threaded=True,
        use_reloader=False
    )
