# 🤖 Neural Nexus - AI Gesture Control System

An advanced real-time hand gesture recognition system with training capabilities and interactive games, built with MediaPipe, Flask, and vanilla JavaScript.

## ✨ Features

### 🔍 Recognition Mode
- **Real-time gesture detection** with <100ms latency
- **Smooth gesture buffering** to prevent jittery detection
- **High accuracy** with confidence scores
- **Multiple gesture support**: Thumbs up, Peace, OK, Rock, Pointing, and numeric counting (1-5)
- **Live FPS monitoring** and performance stats

### 🎓 Training Mode
- **Custom gesture training** - teach the system your own gestures
- **Configurable sample collection** (10-100 samples per gesture)
- **Save/load gesture models** for persistent learning
- **Real-time training feedback** with progress tracking

### 🐍 Game Mode
- **Gesture-controlled Snake game** with ultra-responsive controls
- **Finger-mapped controls**:
  - ☝️ 1 Finger = UP
  - ✌️ 2 Fingers = DOWN
  - 🤟 3 Fingers = RIGHT
  - 🖖 4 Fingers = LEFT
- **Optimized input lag** (<100ms response time)
- **Real-time score tracking**

## 🚀 Quick Start

### Prerequisites
- Python 3.8+
- Webcam
- Modern web browser (Chrome/Firefox recommended)

### Installation

1. **Clone or download the project files**

2. **Install Python dependencies**:
```bash
pip install -r requirements.txt
```

3. **Run the server**:
```bash
python app.py
```

4. **Open your browser**:
```
http://localhost:5000
```

5. **Allow camera access** when prompted

## 📁 Project Structure

```
neural-nexus/
├── app.py                 # Flask backend with optimized processing
├── gesture_nexus.html     # Frontend UI with three modes
├── requirements.txt       # Python dependencies
├── gesture_model.json     # Saved training data (auto-generated)
└── README.md             # This file
```

## 🔧 Key Improvements Over Original

### 1. **Faster Response Times**
- ✅ Reduced buffer size from 10 to 3 frames
- ✅ Camera buffer size set to 1 for minimal latency
- ✅ Removed unnecessary delays in processing loop
- ✅ Optimized MediaPipe settings for speed

### 2. **Better Accuracy**
- ✅ Improved finger detection thresholds
- ✅ Gesture smoothing with weighted buffer
- ✅ Enhanced pattern matching for special gestures
- ✅ Confidence scoring for each detection

### 3. **Training System**
- ✅ **NEW**: Custom gesture training mode
- ✅ **NEW**: Save/load trained models
- ✅ **NEW**: Configurable sample collection
- ✅ **NEW**: Real-time training progress

### 4. **Camera Handling**
- ✅ Single camera instance shared across modes
- ✅ Proper camera initialization and cleanup
- ✅ Thread-safe camera access with locks
- ✅ Automatic camera recovery on errors

### 5. **Snake Game Optimizations**
- ✅ Direct finger-to-direction mapping
- ✅ Removed input buffering for instant response
- ✅ Faster game loop (100ms → optimized timing)
- ✅ Smoother gesture → movement translation

### 6. **UI/UX Enhancements**
- ✅ Cyberpunk/futuristic design aesthetic
- ✅ Distinctive typography (Orbitron + JetBrains Mono)
- ✅ Animated backgrounds and effects
- ✅ Real-time FPS and performance monitoring
- ✅ Responsive layout for all screen sizes

## 🎮 Usage Guide

### Recognition Mode
1. Switch to **RECOGNIZE** mode
2. Place your hand in front of the camera
3. Try different gestures:
   - 👍 Thumbs up
   - ✌️ Peace sign
   - 👌 OK gesture
   - 🤘 Rock sign
   - ☝️ Pointing
   - Count fingers 1-5

### Training Mode
1. Switch to **TRAIN** mode
2. Select a gesture type from the dropdown
3. Set the number of samples (default: 30)
4. Click **CAPTURE** and hold the gesture
5. Repeat for all gestures you want to train
6. Click **SAVE MODEL** to persist training data

### Game Mode
1. Switch to **GAME** mode
2. Use finger gestures to control the snake:
   - 1 finger = Move UP
   - 2 fingers = Move DOWN
   - 3 fingers = Move RIGHT
   - 4 fingers = Move LEFT
3. Eat food (red dots) to grow and score points
4. Avoid walls and your own tail

## 🛠️ Technical Details

### Backend Architecture
- **Flask** server with CORS enabled
- **MediaPipe Hands** for landmark detection
- **Threading** for concurrent camera processing
- **Deque-based buffering** for smooth detection
- **JSON** for model persistence

### Frontend Architecture
- **Pure JavaScript** - no frameworks
- **MediaPipe Web** for hand tracking visualization
- **Canvas API** for game rendering
- **CSS3 animations** for smooth UI
- **Responsive grid layout**

### Performance Optimizations
1. **Camera Settings**:
   - Resolution: 1280x720
   - FPS: 30
   - Buffer: 1 frame (minimal latency)

2. **MediaPipe Settings**:
   - Model complexity: 1 (balanced)
   - Detection confidence: 0.75
   - Tracking confidence: 0.75

3. **Processing**:
   - Frame skip: None (process every frame)
   - Buffer size: 3 frames
   - Thread-safe operations

## 🐛 Troubleshooting

### Camera not working
- Check browser permissions (allow camera access)
- Ensure no other app is using the camera
- Try refreshing the page
- Check console for error messages

### Low FPS / Lag
- Close other programs using the camera
- Reduce browser tab count
- Check CPU usage
- Try lowering camera resolution in `app.py`

### Gestures not detecting
- Ensure good lighting
- Keep hand fully visible in frame
- Check that fingers are clearly separated
- Try adjusting `min_detection_confidence` in code

### Snake game too fast/slow
- Adjust `setInterval` timing in `updateGame()` function
- Default is 100ms, increase for slower, decrease for faster

## 🔮 Future Enhancements

- [ ] Machine learning-based custom gesture classification
- [ ] Multi-hand tracking support
- [ ] Additional games (Flappy Bird, Pong)
- [ ] Gesture macro recording
- [ ] Mobile app version
- [ ] Gesture-to-keyboard/mouse mapping
- [ ] Screen recording with gesture overlay

## 📝 API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | Serve main HTML page |
| `/api/gesture` | GET | Get current gesture data |
| `/api/camera/start` | POST | Start camera processing |
| `/api/camera/stop` | POST | Stop camera processing |
| `/api/training/save` | POST | Save training data |
| `/api/training/load` | GET | Load training data |
| `/api/stats` | GET | Get system statistics |

## 🤝 Contributing

Feel free to:
- Report bugs
- Suggest features
- Submit pull requests
- Share your trained gesture models

## 📄 License

MIT License - feel free to use this project for personal or commercial purposes.

## 🙏 Acknowledgments

- **MediaPipe** by Google for hand tracking
- **Flask** for the web framework
- **OpenCV** for computer vision
- The open-source community

---

Built with ⚡ by Claude | Optimized for real-time performance
