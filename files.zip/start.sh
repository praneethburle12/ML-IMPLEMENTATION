#!/bin/bash

echo "🤖 Neural Nexus - Starting Gesture Control System..."
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed. Please install it first."
    exit 1
fi

# Check if requirements are installed
echo "📦 Checking dependencies..."
pip3 install -r requirements.txt --quiet

# Start the server
echo ""
echo "🚀 Launching server..."
echo ""
python3 app.py
